
# Continue Implementing High-Priority Audit Fixes

## Overview

This plan continues implementing the audit fixes from the comprehensive design system analysis. The previous implementation addressed WF-01, WF-02, CV-01, and CV-02. This phase focuses on the remaining high-priority gaps: data flow connections (DF-01, DF-02, DF-06), cross-tool validation (CV-03, CV-04), and the building snapshot gap (TC-04).

---

## Implementation Summary

| Gap ID | Description | Status |
|--------|-------------|--------|
| WF-01 | Psychrometric to Coil Selection | Done |
| WF-02 | Chiller to CHW Pump | Done |
| CV-01 | Reverse capacity check | Done |
| CV-02 | Boiler efficiency vs return temp | Done |
| CV-03 | Expansion Tank vs System Volume | To implement |
| CV-04 | Control Valve Authority | To implement |
| DF-01 | Chiller evaporator flow to CHW Pump | To implement |
| DF-02 | Boiler heating flow to HW Pump | To implement |
| TC-04 | Building-level snapshot population | Already implemented (verified in edge function) |

---

## Part 1: Add Data Flow Connections (DF-01, DF-02)

### File: `src/hooks/useDesignDataFlow.ts`

**Add Chiller Selections Hook Import (line 11):**
```typescript
import { useChillerSelections, ChillerSelection } from './useChillerSelections';
```

**Add Chiller Selections State (lines 210-215):**
```typescript
// NEW: Fetch Chiller Selections for evaporator flow
const {
  data: chillerSelections,
  isLoading: loadingChillers,
} = useChillerSelections(projectId || undefined);
```

**Update isLoading (line 217):**
```typescript
const isLoading = loadingTerminalUnits || loadingDuctSystems || loadingPipeSystems ||
                  loadingLoads || loadingVentilation || loadingEquipment || loadingAHU || 
                  loadingCHWPlants || loadingHWPlants || loadingBoilers || loadingChillers;
```

**Add Interface for Chiller Data (after line 86):**
```typescript
export interface UpstreamChillerData {
  available: boolean;
  selectionCount: number;
  totalCapacityTons: number;
  totalEvaporatorFlowGpm: number;
  items: ChillerSelection[];
}
```

**Update UpstreamData Interface (line 98):**
```typescript
chillerSelections: UpstreamChillerData;
```

**Add Chiller Data Processing (after line 288):**
```typescript
// Calculate Chiller Selection totals for pump flow
const totalChillerCapacityTons = chillerSelections?.reduce(
  (sum, c) => sum + (c.rated_capacity_tons || 0), 0
) || 0;
// Standard evaporator flow = 2.4 GPM/ton for CHW
const totalEvaporatorFlowGpm = totalChillerCapacityTons * 2.4;
```

**Add Chiller Data to Return Object (after line 355):**
```typescript
chillerSelections: {
  available: (chillerSelections?.length || 0) > 0,
  selectionCount: chillerSelections?.length || 0,
  totalCapacityTons: totalChillerCapacityTons,
  totalEvaporatorFlowGpm: totalEvaporatorFlowGpm,
  items: chillerSelections || [],
},
```

**Add DF-01: Chiller to CHW Pump Recommendation (after line 860):**
```typescript
// ============ DF-01: Chiller Evaporator Flow → CHW Pump Selection ============
if (
  currentTool.includes('pump') && 
  data.chillerSelections?.available &&
  data.chillerSelections.totalEvaporatorFlowGpm > 0
) {
  recommendations.push({
    id: 'chiller-to-chwpump',
    type: 'pipe-to-pump',
    title: 'Chiller Evaporator Flow Data Available',
    description: `Size CHW pump for ${data.chillerSelections.totalEvaporatorFlowGpm.toFixed(0)} GPM from ${data.chillerSelections.selectionCount} chiller(s) @ 2.4 GPM/ton`,
    actionLabel: 'Import Evaporator Flow',
    actionPath: `/design/pump-selection?project=${projectId}&type=chw`,
    sourceData: {
      name: 'Evaporator Flow',
      value: `${data.chillerSelections.totalEvaporatorFlowGpm.toFixed(0)} GPM`,
    },
  });
}
```

**Add DF-02: Boiler to HW Pump Recommendation (update existing, line 842-861):**
The existing `boiler-to-hwpump` recommendation is already present but needs enhancement to calculate actual flow GPM based on delta-T:

```typescript
// ============ DF-02: Boiler Heating Flow → HW Pump Selection ============
if (
  currentTool.includes('pump') && 
  data.boilerSelections.available &&
  data.boilerSelections.totalCapacityMbh > 0
) {
  // Calculate flow: GPM = MBH / (500 * ΔT), typical ΔT = 20°F
  const hwDeltaT = 20;
  const hwFlowGpm = (data.boilerSelections.totalCapacityMbh * 1000) / (500 * hwDeltaT);
  recommendations.push({
    id: 'boiler-to-hwpump',
    type: 'boiler-to-hwpump',
    title: 'Boiler Selection Data Available',
    description: `Size HW pumps for ${hwFlowGpm.toFixed(0)} GPM from ${data.boilerSelections.selectionCount} boiler(s) @ ${hwDeltaT}°F ΔT`,
    actionLabel: 'Import Boiler Flow',
    actionPath: `/design/pump-selection?project=${projectId}&type=hw`,
    sourceData: {
      name: 'HW Flow',
      value: `${hwFlowGpm.toFixed(0)} GPM`,
    },
  });
}
```

---

## Part 2: Add Cross-Tool Validation Rules (CV-03, CV-04)

### File: `src/hooks/useCrossToolValidation.ts`

**Add Expansion Tank and Control Valve Hooks Import (after line 23):**
```typescript
import { useExpansionTankSelections } from './useExpansionTankSelections';
import { useControlValveSelections } from './useControlValveSelections';
```

**Add Hook Calls (after line 212):**
```typescript
const { data: expansionTankSelections, isLoading: loadingExpansionTanks } = useExpansionTankSelections(projectId ?? undefined);
const { data: controlValveSelections, isLoading: loadingControlValves } = useControlValveSelections(projectId ?? undefined);
```

**Update isLoading (line 214-219):**
```typescript
const isLoading = loadingLoads || loadingEquipment || loadingVentilation || 
                  loadingTerminals || loadingDucts || loadingPipes || loadingAHU ||
                  loadingFans || loadingPumps || loadingERV || loadingVRF || loadingDiffusers ||
                  loadingInsulation || loadingAcoustic || loadingCoils || loadingFilters || 
                  loadingCoolingTowers || loadingChillers || loadingCHWPlants || loadingHWPlants || 
                  loadingBoilers || loadingPsychrometric || loadingExpansionTanks || loadingControlValves;
```

**Add Timestamps (after line 270):**
```typescript
const expansionTankEarliest = getEarliestTimestamp(expansionTankSelections || []);
const controlValveEarliest = getEarliestTimestamp(controlValveSelections || []);
```

**Add CV-03: Expansion Tank vs System Volume (after line 332):**
```typescript
// ============ CV-03: Pipe System → Expansion Tank (System Volume Check) ============
if (currentTool === 'expansion-tank-sizing' && pipeLatest && expansionTankEarliest) {
  const staleness = calculateStaleness(pipeLatest, expansionTankEarliest);
  if (staleness.isStale) {
    dependencies.push({
      id: 'pipe-to-expansion-tank',
      upstream: {
        toolName: 'Pipe Systems',
        toolType: 'pipe-system',
        tableName: 'pipe_systems',
        latestUpdatedAt: pipeLatest,
        itemCount: pipeSystems?.length || 0,
        path: `/design/pipe-designer?project=${projectId}`,
      },
      downstream: {
        toolName: 'Expansion Tank Sizing',
        toolType: 'expansion-tank-sizing',
        tableName: 'expansion_tank_selections',
        createdAt: expansionTankEarliest,
        itemCount: expansionTankSelections?.length || 0,
      },
      status: 'stale',
      staleDurationMinutes: staleness.minutesStale,
      staleDurationText: formatDistanceToNow(new Date(pipeLatest), { addSuffix: true }),
      severity: staleness.severity,
      description: 'Pipe system was updated. Expansion tank sizing should be recalculated for new system volume.',
    });
  }
}
```

**Add CV-04: Control Valve Authority (after CV-03):**
```typescript
// ============ CV-04: Pump Selection → Control Valve (Authority Check) ============
if (currentTool === 'control-valve-sizing' && pipeLatest && controlValveEarliest) {
  const staleness = calculateStaleness(pipeLatest, controlValveEarliest);
  if (staleness.isStale) {
    dependencies.push({
      id: 'pipe-to-control-valve',
      upstream: {
        toolName: 'Pipe Systems',
        toolType: 'pipe-system',
        tableName: 'pipe_systems',
        latestUpdatedAt: pipeLatest,
        itemCount: pipeSystems?.length || 0,
        path: `/design/pipe-designer?project=${projectId}`,
      },
      downstream: {
        toolName: 'Control Valve Sizing',
        toolType: 'control-valve-sizing',
        tableName: 'control_valve_selections',
        createdAt: controlValveEarliest,
        itemCount: controlValveSelections?.length || 0,
      },
      status: 'stale',
      staleDurationMinutes: staleness.minutesStale,
      staleDurationText: formatDistanceToNow(new Date(pipeLatest), { addSuffix: true }),
      severity: staleness.severity,
      description: 'Pipe system pressure drop changed. Control valve Cv and authority should be recalculated.',
    });
  }
}

// ============ CV-04: Pump → Control Valve Authority Alert ============
if (currentTool === 'control-valve-sizing') {
  // Check control valve selections for low authority
  controlValveSelections?.forEach(cv => {
    const authority = cv.valve_authority || 0;
    if (authority > 0 && authority < 0.25) {
      dependencies.push({
        id: `cv-authority-critical-${cv.id}`,
        upstream: {
          toolName: 'Pump Selection',
          toolType: 'pump-selection',
          tableName: 'pump_selections',
          latestUpdatedAt: pipeLatest,
          itemCount: pumpSelections?.length || 0,
          path: `/design/pump-selection?project=${projectId}`,
        },
        downstream: {
          toolName: 'Control Valve Sizing',
          toolType: 'control-valve-sizing',
          tableName: 'control_valve_selections',
          createdAt: cv.created_at || null,
          itemCount: 1,
        },
        status: 'stale',
        staleDurationMinutes: 0,
        staleDurationText: 'now',
        severity: 'critical',
        description: `Control valve authority is ${(authority * 100).toFixed(0)}% which is below minimum 25%. Valve may hunt or provide poor control.`,
      });
    } else if (authority > 0 && authority < 0.5) {
      dependencies.push({
        id: `cv-authority-warning-${cv.id}`,
        upstream: {
          toolName: 'Pump Selection',
          toolType: 'pump-selection',
          tableName: 'pump_selections',
          latestUpdatedAt: pipeLatest,
          itemCount: pumpSelections?.length || 0,
          path: `/design/pump-selection?project=${projectId}`,
        },
        downstream: {
          toolName: 'Control Valve Sizing',
          toolType: 'control-valve-sizing',
          tableName: 'control_valve_selections',
          createdAt: cv.created_at || null,
          itemCount: 1,
        },
        status: 'stale',
        staleDurationMinutes: 0,
        staleDurationText: 'now',
        severity: 'warning',
        description: `Control valve authority is ${(authority * 100).toFixed(0)}% which is below recommended 50%. Consider sizing valve for higher pressure drop.`,
      });
    }
  });
}
```

---

## Part 3: Add Terminal Reheat to HW Plant Flow (DF-06)

### File: `src/hooks/useDesignDataFlow.ts`

**Add Recommendation for Terminal Reheat to HW Plant (after line 840):**
```typescript
// ============ DF-06: Terminal Unit Reheat → HW Plant Sizing ============
if (
  currentTool.includes('hw-plant') || currentTool.includes('hot-water-plant')
) {
  // Calculate total reheat load from terminal units
  const terminalReheatBtuh = data.terminalUnits?.items?.reduce(
    (sum, tu) => sum + (tu.reheat_capacity_btuh || 0), 0
  ) || 0;
  
  if (terminalReheatBtuh > 0) {
    const reheatMbh = terminalReheatBtuh / 1000;
    recommendations.push({
      id: 'terminal-to-hwplant',
      type: 'load-to-equipment',
      title: 'Terminal Unit Reheat Data Available',
      description: `Include ${reheatMbh.toFixed(0)} MBH terminal reheat in HW plant sizing from ${data.terminalUnits.count} terminal unit(s)`,
      actionLabel: 'Import Reheat Load',
      actionPath: `/design/hot-water-plant?project=${projectId}`,
      sourceData: {
        name: 'Terminal Reheat',
        value: `${reheatMbh.toFixed(0)} MBH`,
      },
    });
  }
}
```

---

## Summary of Changes

| File | Change Type | Description |
|------|-------------|-------------|
| `src/hooks/useDesignDataFlow.ts` | Enhancement | Add chiller evaporator flow (DF-01), improve boiler flow calc (DF-02), add terminal reheat flow (DF-06) |
| `src/hooks/useCrossToolValidation.ts` | Enhancement | Add expansion tank validation (CV-03), add control valve authority checks (CV-04) |

---

## Technical Notes

1. **DF-01/DF-02 Calculations:**
   - CHW evaporator flow uses 2.4 GPM/ton standard
   - HW flow uses `GPM = MBH / (500 * ΔT)` with 20°F default delta-T

2. **CV-04 Authority Thresholds:**
   - Critical: < 25% authority (severe hunting)
   - Warning: 25-50% authority (suboptimal control)
   - Pass: >= 50% authority (good modulating control)

3. **Building Snapshot Gap (TC-04):**
   - Already implemented in edge function (lines 460-492)
   - The `design_completeness_building_snapshots` table IS being populated correctly

4. **Backward Compatibility:**
   - New upstream data interfaces use optional properties
   - Existing recommendations continue to work unchanged
